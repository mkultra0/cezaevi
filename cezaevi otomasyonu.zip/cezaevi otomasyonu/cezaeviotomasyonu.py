from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
import mysql.connector
from tkinter import messagebox


class Suclu():
    def __init__(self, otomasyon):
        self.otomasyon = otomasyon
        self.otomasyon.geometry('1530x790')
        self.otomasyon.title('Cezaevi Otomasyonu')

        # değişkenler

        self.var_tc = StringVar()
        self.var_dosyano = StringVar()
        self.var_isim = StringVar()
        self.var_soyisim = StringVar()
        self.var_dgm = StringVar()
        self.var_giristarihi = StringVar()
        self.var_hucreno = StringVar()
        self.var_tahliye = StringVar()
        self.var_meslek = StringVar()
        self.var_suc = StringVar()
        self.var_kayiteden = StringVar()
        self.var_baba = StringVar()
        self.var_cinsiyet = StringVar()
        self.var_mhal = StringVar()

        lbl_title = Label(self.otomasyon, text='Cezaevi Otomasyonu Yazılımı', font=('times new roman', 40, 'bold'),
                          bg='black', fg='gold')
        lbl_title.place(x=0, y=0, width=1530, height=70)
        # logonun kodu
        img_logo = Image.open('resimler/egmlogo.png')
        img_logo = img_logo.resize((60, 60), Image.ANTIALIAS)
        self.photo_logo = ImageTk.PhotoImage(img_logo)

        self.logo = Label(self.otomasyon, image=self.photo_logo)
        self.logo.place(x=350, y=5, width=60, height=60)

        # ust Frame
        img_frame = Frame(self.otomasyon, bd=2, relief=RIDGE, bg='white')
        img_frame.place(x=0, y=70, width=1530, height=130)

        img1 = Image.open('resimler/img1.png')
        img1 = img1.resize((540, 200), Image.ANTIALIAS)
        self.photo1 = ImageTk.PhotoImage(img1)

        self.img_1 = Label(img_frame, image=self.photo1)
        self.img_1.place(x=0, y=0, width=540, height=160)
        self.img_1 = Label(img_frame, image=self.photo1)
        self.img_1.place(x=540, y=0, width=540, height=160)
        self.img_1 = Label(img_frame, image=self.photo1)
        self.img_1.place(x=1000, y=0, width=540, height=160)

        # Ana Frame
        ana_frame = Frame(self.otomasyon, bd=2, relief=RIDGE, bg='white')
        ana_frame.place(x=10, y=200, width=1500, height=560)
        # ust Frame
        ust_frame = LabelFrame(ana_frame, bd=2, relief=RIDGE, text='Hukumlu Bilgileri',
                               font=('times new roman', 11, 'bold'), fg='red', bg='white')
        ust_frame.place(x=10, y=10, width=1480, height=270)

        # Veri Girişi

        # suçlu TC
        tckimlik = Label(ust_frame, text='TC Kimlik NO:', font=('times new roman', 12, 'bold'), bg='white')
        tckimlik.grid(row=0, column=0, padx=2, sticky=W)

        tckimlikgiris = ttk.Entry(ust_frame, textvariable=self.var_tc, width=22, font=('times new roman', 12, 'bold'))
        tckimlikgiris.grid(row=0, column=1, padx=2, sticky=W)

        # suçlu dosya no
        dosyano = Label(ust_frame, text='Dosya Numarası:', font=('times new roman', 12, 'bold'), bg='white')
        dosyano.grid(row=0, column=2, padx=2, pady=7, sticky=W)

        dosyanogiris = ttk.Entry(ust_frame, textvariable=self.var_dosyano, width=22,
                                 font=('times new roman', 12, 'bold'))
        dosyanogiris.grid(row=0, column=3, padx=2, pady=7, sticky=W)

        # isim
        isim = Label(ust_frame, text='Adı:', font=('times new roman', 12, 'bold'), bg='white')
        isim.grid(row=1, column=0, padx=2, pady=7, sticky=W)

        isimgiris = ttk.Entry(ust_frame, textvariable=self.var_isim, width=22, font=('times new roman', 12, 'bold'))
        isimgiris.grid(row=1, column=1, padx=2, pady=7, sticky=W)

        # soyisim
        soyisim = Label(ust_frame, text='Soyadı:', font=('times new roman', 12, 'bold'), bg='white')
        soyisim.grid(row=1, column=2, padx=2, pady=7, sticky=W)

        soyisimgiris = ttk.Entry(ust_frame, textvariable=self.var_soyisim, width=22,
                                 font=('times new roman', 12, 'bold'))
        soyisimgiris.grid(row=1, column=3, padx=2, pady=7, sticky=W)

        # dogum tarihi
        dgm = Label(ust_frame, text='Doğum Tarihi:', font=('times new roman', 12, 'bold'), bg='white')
        dgm.grid(row=2, column=0, padx=2, pady=7, sticky=W)

        dgmgiris = ttk.Entry(ust_frame, textvariable=self.var_dgm, width=22, font=('times new roman', 12, 'bold'))
        dgmgiris.grid(row=2, column=1, padx=2, pady=7, sticky=W)

        # cezaevi giris tarihi
        giristarihi = Label(ust_frame, text='Hukum Tarihi:', font=('times new roman', 12, 'bold'), bg='white')
        giristarihi.grid(row=2, column=2, padx=2, pady=7, sticky=W)

        giristarihigiris = ttk.Entry(ust_frame, textvariable=self.var_giristarihi, width=22,
                                     font=('times new roman', 12, 'bold'))
        giristarihigiris.grid(row=2, column=3, padx=2, pady=7, sticky=W)

        # hucre no
        hucreno = Label(ust_frame, text='Hucre No:', font=('times new roman', 12, 'bold'), bg='white')
        hucreno.grid(row=3, column=0, padx=2, pady=7, sticky=W)

        hucrenogiris = ttk.Entry(ust_frame, textvariable=self.var_hucreno, width=22,
                                 font=('times new roman', 12, 'bold'))
        hucrenogiris.grid(row=3, column=1, padx=2, pady=7, sticky=W)

        # tahliye tarihi
        tahliye = Label(ust_frame, text='Tahliye Tarihi:', font=('times new roman', 12, 'bold'), bg='white')
        tahliye.grid(row=3, column=2, padx=2, pady=7, sticky=W)

        tahliyegiris = ttk.Entry(ust_frame, textvariable=self.var_tahliye, width=22,
                                 font=('times new roman', 12, 'bold'))
        tahliyegiris.grid(row=3, column=3, padx=2, pady=7, sticky=W)

        # Meslek
        meslek = Label(ust_frame, text='Meslek:', font=('times new roman', 12, 'bold'), bg='white')
        meslek.grid(row=4, column=0, padx=2, pady=7, sticky=W)

        meslekgiris = ttk.Entry(ust_frame, textvariable=self.var_meslek, width=22, font=('times new roman', 12, 'bold'))
        meslekgiris.grid(row=4, column=1, padx=2, pady=7, sticky=W)

        # Kayıt eden kişi
        kayiteden = Label(ust_frame, text='Kayıt Eden Görevli:', font=('times new roman', 12, 'bold'), bg='white')
        kayiteden.grid(row=4, column=2, padx=2, pady=7, sticky=W)

        kayitedengiris = ttk.Entry(ust_frame, textvariable=self.var_kayiteden, width=22,
                                   font=('times new roman', 12, 'bold'))
        kayitedengiris.grid(row=4, column=3, padx=2, pady=7, sticky=W)

        # Suç No
        suc = Label(ust_frame, text='Suç:', font=('times new roman', 12, 'bold'), bg='white')
        suc.grid(row=0, column=4, padx=2, pady=7, sticky=W)

        sucgiris = ttk.Entry(ust_frame, textvariable=self.var_suc, width=22, font=('times new roman', 12, 'bold'))
        sucgiris.grid(row=0, column=5, padx=2, pady=7, sticky=W)

        # Baba Adı
        baba = Label(ust_frame, text='Baba Adı:', font=('times new roman', 12, 'bold'), bg='white')
        baba.grid(row=1, column=4, padx=2, pady=7, sticky=W)

        babagiris = ttk.Entry(ust_frame, textvariable=self.var_baba, width=22, font=('times new roman', 12, 'bold'))
        babagiris.grid(row=1, column=5, padx=2, pady=7, sticky=W)

        # cinsiyet
        cinsiyet = Label(ust_frame, text='Cinsiyet:', font=('times new roman', 12, 'bold'), bg='white')
        cinsiyet.grid(row=2, column=4, padx=2, pady=7, sticky=W)

        # medenihal
        mhal = Label(ust_frame, text='Medeni Hal:', font=('times new roman', 12, 'bold'), bg='white')
        mhal.grid(row=3, column=4, padx=2, pady=7, sticky=W)

        # radio button cinsiyet
        radio_frame_cinsiyet = Frame(ust_frame, bd=2, relief=RIDGE, bg='white')
        radio_frame_cinsiyet.place(x=730, y=90, width=190, height=30)

        erkek = Radiobutton(radio_frame_cinsiyet, variable=self.var_cinsiyet, text='Erkek', value='Erkek',
                            font=('times new roman', 10, 'bold'), bg='white')
        erkek.grid(row=0, column=0, pady=2, padx=5, sticky=W)
        self.var_cinsiyet.set('Erkek')

        kadin = Radiobutton(radio_frame_cinsiyet, variable=self.var_cinsiyet, text='Kadın', value='Kadın',
                            font=('times new roman', 10, 'bold'), bg='white')
        kadin.grid(row=0, column=1, pady=2, padx=5, sticky=W)

        # radio button medeni hal
        radio_frame_mhal = Frame(ust_frame, bd=2, relief=RIDGE, bg='white')
        radio_frame_mhal.place(x=730, y=130, width=190, height=30)

        evli = Radiobutton(radio_frame_mhal, variable=self.var_mhal, text='Evli', value='Evli',
                           font=('times new roman', 10, 'bold'), bg='white')
        evli.grid(row=0, column=0, pady=2, padx=5, sticky=W)
        self.var_mhal.set('Evli')

        bekar = Radiobutton(radio_frame_mhal, variable=self.var_mhal, text='Bekar', value='Bekar',
                            font=('times new roman', 10, 'bold'), bg='white')
        bekar.grid(row=0, column=1, pady=2, padx=5, sticky=W)

        # buton Frame
        buton_frame = Frame(ust_frame, bd=2, relief=RIDGE, bg='white')
        buton_frame.place(x=5, y=200, width=620, height=45)

        # ekleme butonu

        ekle_buton = Button(buton_frame,command=self.veri_ekle, text='Hukumluyu Ekle', font=('arial', 13, 'bold'), width=14, bg='green',
                            fg='white')
        ekle_buton.grid(row=0, column=0, padx=3, pady=5)

        # guncelle butonu

        guncelle_buton = Button(buton_frame,command=self.veri_guncelle, text='Guncelle', font=('arial', 13, 'bold'), width=14, bg='blue',
                                fg='white')
        guncelle_buton.grid(row=0, column=1, padx=3, pady=5)

        # temizle butonu

        temizle_buton = Button(buton_frame,command=self.veri_temizle, text='Temizle', font=('arial', 13, 'bold'), width=14, bg='blue', fg='white')
        temizle_buton.grid(row=0, column=2, padx=3, pady=5)

        # sil butonu

        sil_buton = Button(buton_frame,command=self.hukumlu_sil, text='Hukumluyu Sil', font=('arial', 13, 'bold'), width=14, bg='red',fg='white')
        sil_buton.grid(row=0, column=3, padx=3, pady=5)

        # guvenlik foto
        img_polis = Image.open('resimler/polis2.png')
        img_polis = img_polis.resize((214, 235), Image.ANTIALIAS)
        self.photopolis = ImageTk.PhotoImage(img_polis)

        self.img_polis = Label(ust_frame, image=self.photopolis, bg='white')
        self.img_polis.place(x=1000, y=0, width=470, height=245)

        # Alt Frame
        alt_frame = LabelFrame(ana_frame, bd=2, relief=RIDGE, text='Hukumluler Listesi',
                               font=('times new roman', 11, 'bold'), fg='red', bg='white')
        alt_frame.place(x=10, y=280, width=1480, height=270)

        arama_frame = LabelFrame(alt_frame, bd=2, relief=RIDGE, text='Ara', font=('times new roman', 11, 'bold'),
                                 fg='red', bg='white')
        arama_frame.place(x=0, y=0, width=1470, height=60)

        filtrele = Label(arama_frame, font=('arial', 12, 'bold'), text='Filtrele', bg='red', fg='white')
        filtrele.grid(row=0, column=0, padx=2, pady=7, sticky=W)

        self.var_com_veri_ara=StringVar()
        filtre = ttk.Combobox(arama_frame,textvariable=self.var_com_veri_ara, font=('arial', 11, 'bold'), width=18, state='readonly')
        filtre['value'] = ('Seç', 'tc', 'dosyano', 'isim','soyisim','dgm','giristarihi','hücreno','tahliye','meslek','suc','kayiteden','baba','cinsiyet','mhal')
        filtre.current(0)
        filtre.grid(row=0, column=1, sticky=W, padx=5)

        self.var_veri_ara=StringVar()
        aramagiris = Entry(arama_frame, textvariable=self.var_veri_ara, font=('times new roman', 12, 'bold'), bg='white')
        aramagiris.grid(row=0, column=2, padx=2, pady=7, sticky=W)

        # arama butonu

        arama_buton = Button(arama_frame,command=self.veri_ara, text='Ara', font=('arial', 13, 'bold'), width=14, bg='blue', fg='white')
        arama_buton.grid(row=0, column=3, padx=3, pady=5)

        # hepsi butonu

        hepsi_buton = Button(arama_frame,command=self.veri_yukle, text='Hepsini Göster', font=('arial', 13, 'bold'), width=14, bg='blue',
                             fg='white')
        hepsi_buton.grid(row=0, column=4, padx=3, pady=5)

        egmyazi = Label(arama_frame, text='EMNİYET GENEL MÜDÜRLÜĞÜ', font=('times new roman', 30, 'bold'), bg='white',
                        fg='dark blue')
        egmyazi.grid(row=0, column=5, padx=50, pady=0, sticky=W)

        # Tablo Frame
        tablo_frame = Frame(alt_frame, bd=2, relief=RIDGE)
        tablo_frame.place(x=0, y=60, width=1470, height=170)

        # scroll bar
        scroll_x = ttk.Scrollbar(tablo_frame, orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(tablo_frame, orient=VERTICAL)

        self.suclutablosu = ttk.Treeview(tablo_frame, column=('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14'))
        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)

        scroll_x.config(command=self.suclutablosu.xview)
        scroll_y.config(command=self.suclutablosu.yview)

        self.suclutablosu.heading('1', text='TC Kimlik No')
        self.suclutablosu.heading('2', text='Dosya NO')
        self.suclutablosu.heading('3', text='İsim')
        self.suclutablosu.heading('4', text='Soy İsim')
        self.suclutablosu.heading('5', text='Doğum Günü')
        self.suclutablosu.heading('6', text='Hüküm Tarihi')
        self.suclutablosu.heading('7', text='Hücre NO')
        self.suclutablosu.heading('8', text='Tahliye Tarihi')
        self.suclutablosu.heading('9', text='Meslek')
        self.suclutablosu.heading('10', text='Suç')
        self.suclutablosu.heading('11', text='Kayıt Eden Görevli')
        self.suclutablosu.heading('12', text='Baba Adı')
        self.suclutablosu.heading('13', text='Cinsiyet')
        self.suclutablosu.heading('14', text='Medeni Hal')

        self.suclutablosu['show'] = 'headings'

        self.suclutablosu.column('1', width=100)
        self.suclutablosu.column('2', width=100)
        self.suclutablosu.column('3', width=100)
        self.suclutablosu.column('4', width=100)
        self.suclutablosu.column('5', width=100)
        self.suclutablosu.column('6', width=100)
        self.suclutablosu.column('7', width=100)
        self.suclutablosu.column('8', width=100)
        self.suclutablosu.column('9', width=100)
        self.suclutablosu.column('10', width=100)
        self.suclutablosu.column('11', width=100)
        self.suclutablosu.column('12', width=100)
        self.suclutablosu.column('13', width=100)
        self.suclutablosu.column('14', width=100)


        self.suclutablosu.pack(fill=BOTH, expand=1)

        self.suclutablosu.bind("<ButtonRelease>",self.hukumlu_cagir)



        self.veri_yukle()

    def veri_ekle(self):
        if self.var_tc.get() == "":
            messagebox.showerror('Hata', 'Tüm Alanlar Doldurulmalıdır.', parent=self.otomasyon)
        else:
            try:
                conn = mysql.connector.connect(
                    host='localhost',
                    user='root',
                    passwd='',
                    database='manage')
                my_cursor = conn.cursor()
                my_cursor.execute('INSERT INTO hukumluler VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)', (self.var_tc.get(),
                                                                                           self.var_dosyano.get(),
                                                                                           self.var_isim.get(),
                                                                                           self.var_soyisim.get(),
                                                                                           self.var_dgm.get(),
                                                                                           self.var_giristarihi.get(),
                                                                                           self.var_hucreno.get(),
                                                                                           self.var_tahliye.get(),
                                                                                           self.var_meslek.get(),
                                                                                           self.var_suc.get(),
                                                                                           self.var_kayiteden.get(),
                                                                                           self.var_baba.get(),
                                                                                           self.var_cinsiyet.get(),
                                                                                           self.var_mhal.get()
                                                                                           ))
                conn.commit()
                self.veri_yukle()
                conn.close()
                messagebox.showinfo('Başarılı!', 'Hükümlü bilgileri eklenmiştir.')
            except Exception as es:
                messagebox.showerror('Hata', f'Due To{str(es)}')

    #tabloyu tkinkera yukleme
    def veri_yukle(self):
        conn=mysql.connector.connect(host='localhost', user='root', passwd='', database='manage')
        my_cursor=conn.cursor()
        my_cursor.execute('SELECT * FROM hukumluler')
        data=my_cursor.fetchall()
        if len(data)!=0:
            self.suclutablosu.delete(*self.suclutablosu.get_children())
            for i in data:
                self.suclutablosu.insert('',END,values=i)
            conn.commit()
        conn.close()
    #bilgileri boşluklara geri yukleme kodu
    def hukumlu_cagir(self,event=''):
        cursur_row=self.suclutablosu.focus()
        content=self.suclutablosu.item(cursur_row)
        data=content['values']


        self.var_tc.set(data[0])
        self.var_dosyano.set(data[1])
        self.var_isim.set(data[2])
        self.var_soyisim.set(data[3])
        self.var_dgm.set(data[4])
        self.var_giristarihi.set(data[5])
        self.var_hucreno.set(data[6])
        self.var_tahliye.set(data[7])
        self.var_meslek.set(data[8])
        self.var_suc.set(data[9])
        self.var_kayiteden.set(data[10])
        self.var_baba.set(data[11])
        self.var_cinsiyet.set(data[12])
        self.var_mhal.set(data[13])

    # güncelleme satırı

    def veri_guncelle(self):
        if self.var_tc.get()=="":
            messagebox.showerror('Hata', 'Tüm Alanlar Doldurulmalıdır.', parent=self.otomasyon)
        else:
            try:
                update=messagebox.askyesno('Güncelleme','Hükümlüyü güncellemek istediğinizden emin misiniz?')
                if update>0:
                    conn=mysql.connector.connect(host='localhost', user='root', passwd='', database='manage')
                    my_cursor=conn.cursor()
                    my_cursor.execute('update hukumluler set dosyano=%s, isim=%s, soyisim=%s, dgm=%s, giristarihi=%s, hücreno=%s, tahliye=%s, meslek=%s, suc=%s, kayiteden=%s, baba=%s, cinsiyet=%s, mhal=%s where tc=%s', (
                                                                                           self.var_dosyano.get(),
                                                                                           self.var_isim.get(),
                                                                                           self.var_soyisim.get(),
                                                                                           self.var_dgm.get(),
                                                                                           self.var_giristarihi.get(),
                                                                                           self.var_hucreno.get(),
                                                                                           self.var_tahliye.get(),
                                                                                           self.var_meslek.get(),
                                                                                           self.var_suc.get(),
                                                                                           self.var_kayiteden.get(),
                                                                                           self.var_baba.get(),
                                                                                           self.var_cinsiyet.get(),
                                                                                           self.var_mhal.get(),
                                                                                           self.var_tc.get(),))
                else:
                    if not update:
                        return
                conn.commit()
                self.veri_yukle()
                self.veri_temizle()

                conn.close()
                messagebox.showinfo('Başarılı!', 'Hükümlü bilgileri güncellenmiştir.')
            except Exception as es:
                messagebox.showerror('Hata', f'Due To{str(es)}')


    #hukumlu silme
    def hukumlu_sil(self):
        if self.var_tc.get()=='':
            messagebox.showerror('Hata', 'Tüm alanlar doldurulmalıdır.')
        else:
            try:
                delete=messagebox.askyesno('Sil','Hükümlüyü silmek istediğinizden emin misiniz?')
                if delete>0:
                    conn = mysql.connector.connect(host='localhost', user='root', passwd='', database='manage')
                    my_cursor = conn.cursor()
                    sql='delete from hukumluler where tc=%s'
                    value=(self.var_tc.get(),)
                    my_cursor.execute(sql,value)
                else:
                    if not delete:
                        return
                conn.commit()
                self.veri_yukle()
                conn.close()
                messagebox.showinfo('Başarılı!', 'Hükümlü bilgileri silinmiştir.')
            except Exception as es:
                messagebox.showerror('Hata', f'Due To{str(es)}')
    #temizleme

    def veri_temizle(self):
        self.var_dosyano.set("")
        self.var_isim.set("")
        self.var_soyisim.set("")
        self.var_dgm.set("")
        self.var_giristarihi.set("")
        self.var_hucreno.set("")
        self.var_tahliye.set("")
        self.var_meslek.set("")
        self.var_kayiteden.set("")
        self.var_suc.set("")
        self.var_baba.set("")
        self.var_cinsiyet.set("")
        self.var_mhal.set("")
        self.var_tc.set("")

    # arama
    def veri_ara(self):
        if self.var_com_veri_ara.get()=="":
            messagebox.showerror("Hata","")
        else:
            try:
                conn = mysql.connector.connect(host='localhost', user='root', passwd='', database='manage')
                my_cursor = conn.cursor()
                my_cursor.execute('select * from hukumluler where ' +str(self.var_com_veri_ara.get())+" LIKE'%"+str(self.var_veri_ara.get()+"%'"))
                rows=my_cursor.fetchall()
                if len(rows)!=0:
                    self.suclutablosu.delete(*self.suclutablosu.get_children())
                    for i in rows:
                        self.suclutablosu.insert("",END,values=i)
                conn.commit()
                conn.close()
            except Exception as es:
                messagebox.showerror('Hata', f'Due To{str(es)}')






if __name__ == "__main__":
    otomasyon = Tk()
    obj = Suclu(otomasyon)
    otomasyon.mainloop()
